import { Link } from 'react-router-dom'
import PageWrap from '../components/PageWrap'
import Reveal from '../components/Reveal'
import { IconLeaf, IconArrowLeft, IconArrow } from '../components/icons'

export default function ResponsibleTravel() {
  return (
    <PageWrap>
      <section className="page-hero">
        <div className="wrap">
          <Reveal>
            <div className="breadcrumb">
              <Link to="/">Home</Link> / <span>Responsible Travel</span>
            </div>
            <span className="eyebrow">Eco-Tourism Ethics</span>
            <h1>
              Preserving Jharkhand’s <em>Hidden Waters.</em>
            </h1>
            <p>
              When exploring offbeat and pristine waterfalls, our presence impacts fragile riparian ecosystems,
              forest wildlife, and local indigenous communities. Follow these 6 principles for thoughtful eco-travel.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 16 }}>
        <div className="wrap">
          <div className="dest-grid">
            {[
              { num: '01', title: 'Leave No Trace', desc: 'Carry back all non-biodegradable waste, food wrappers, and plastic bottles to designated town disposal bins.' },
              { num: '02', title: 'Zero Water Pollution', desc: 'Never use synthetic soaps, shampoos, or wash vehicles in natural forest riverbeds and plunge pools.' },
              { num: '03', title: 'Respect Wildlife & Groves', desc: 'Keep noise levels minimum. Do not play loud loudspeakers in sacred forest groves (Sarna Sthal) or wildlife buffer corridors.' },
              { num: '04', title: 'Support Local Livelihoods', desc: 'Engage local village youth as tour guides and buy authentic tribal handicrafts (bamboo, lacquer, forest honey) directly from local families.' },
              { num: '05', title: 'Respect Tribal Culture', desc: 'Always ask permission before photographing village elders, sacred rituals, or tribal homes.' },
              { num: '06', title: 'Stay on Marked Trails', desc: 'Avoid carving new paths through dense undergrowth to prevent soil erosion and disturbance to ground-nesting fauna.' }
            ].map((item, idx) => (
              <Reveal key={item.num} delay={idx * 0.05} className="dest-col-4">
                <div className="glass dcard" style={{ height: '100%' }}>
                  <span style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--ember-deep)', opacity: 0.6 }}>{item.num}</span>
                  <h3 style={{ fontSize: '1.25rem', marginTop: 8, marginBottom: 8 }}>{item.title}</h3>
                  <p style={{ fontSize: '0.88rem', color: 'var(--ink-soft)', lineHeight: 1.6 }}>{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <div style={{ marginTop: 36, textAlign: 'center' }}>
            <Link to="/#discovery" className="btn">
              Explore Hidden Waterfalls <IconArrow />
            </Link>
          </div>
        </div>
      </section>
    </PageWrap>
  )
}
