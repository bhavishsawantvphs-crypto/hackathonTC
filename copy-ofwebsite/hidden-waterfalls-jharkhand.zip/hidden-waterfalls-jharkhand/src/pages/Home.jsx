import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import PageWrap from '../components/PageWrap'
import Reveal from '../components/Reveal'
import InteractiveMap from '../components/InteractiveMap'
import { WATERFALLS } from '../data/waterfalls'
import { IconArrow, IconPin } from '../components/icons'

const FILTER_OPTIONS = [
  { id: 'all', label: 'All Waterfalls (6)' },
  { id: 'suitable', label: '🟢 Suitable / Normal' },
  { id: 'caution', label: '🟡 Caution' },
  { id: 'easy', label: 'Easy Access' },
  { id: 'moderate', label: 'Moderate' },
]

export default function Home() {
  const [filter, setFilter] = useState('all')

  const list = useMemo(() => {
    if (filter === 'all') return WATERFALLS
    if (filter === 'suitable') return WATERFALLS.filter(w => w.safetyStatus === 'suitable')
    if (filter === 'caution') return WATERFALLS.filter(w => w.safetyStatus === 'caution')
    if (filter === 'easy') return WATERFALLS.filter(w => w.accessibilityCategory === 'easy')
    if (filter === 'moderate') return WATERFALLS.filter(w => w.accessibilityCategory === 'moderate')
    return WATERFALLS
  }, [filter])

  return (
    <PageWrap>
      {/* 1. HERO SECTION */}
      <section className="section" style={{ paddingTop: 36, paddingBottom: 24 }}>
        <div className="wrap">
          <Reveal>
            <div className="breadcrumb">
              <span>Jharkhand Eco-Tourism</span> / <span>Offbeat Nature Discovery</span>
            </div>
            <span className="eyebrow">Offbeat &amp; Lesser-Known Destinations</span>
            <h1 style={{ fontSize: '2.85rem', fontWeight: 700, lineHeight: 1.15, marginBottom: 16, color: 'var(--ink)' }}>
              Hidden &amp; Lesser-Known Waterfalls of <em style={{ color: 'var(--accent)' }}>Jharkhand</em>
            </h1>
            <p style={{ fontSize: '1.15rem', color: 'var(--ink-soft)', lineHeight: 1.7, maxWidth: 900, marginBottom: 24 }}>
              Discover offbeat and lesser-known waterfall destinations across Jharkhand.
              Review verified accessibility, nearby medical support, seasonal alerts, and prototype eco-scores
              before deciding whether and how to visit — <strong>without guessing the risk</strong>.
            </p>
            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
              <a href="#discovery" className="btn">
                Discover Waterfalls <IconArrow />
              </a>
              <a href="#map" className="btn outline">
                View Interactive Map
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 2. INTERACTIVE MAP SECTION */}
      <section className="section" id="map" style={{ paddingTop: 16, paddingBottom: 32 }}>
        <div className="wrap">
          <Reveal>
            <div style={{ marginBottom: 20 }}>
              <span className="eyebrow">Interactive Constellation Map</span>
              <h2 style={{ fontSize: '1.85rem', color: 'var(--ink)' }}>
                Locate offbeat waterfalls <em style={{ color: 'var(--accent)' }}>across Jharkhand districts.</em>
              </h2>
              <p style={{ color: 'var(--ink-soft)', maxWidth: 780, marginTop: 4 }}>
                Click on any map marker to preview accessibility rating, seasonal notes, and verified safety context.
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.06}>
            <InteractiveMap filter={filter} />
          </Reveal>
        </div>
      </section>

      {/* 3. DISCOVERY CARDS SECTION (EXACTLY 6 WATERFALLS) */}
      <section className="section" id="discovery" style={{ paddingTop: 16 }}>
        <div className="wrap">
          <Reveal>
            <div style={{ marginBottom: 20 }}>
              <span className="eyebrow">Curated Waterfall Collection</span>
              <h2 style={{ fontSize: '1.85rem', color: 'var(--ink)' }}>
                Select a waterfall <em style={{ color: 'var(--accent)' }}>for complete safety clarity.</em>
              </h2>
            </div>

            <div className="filter-chips" style={{ marginBottom: 28 }}>
              {FILTER_OPTIONS.map((f) => (
                <button
                  key={f.id}
                  className={`chip ${filter === f.id ? 'active' : ''}`}
                  onClick={() => setFilter(f.id)}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="dest-grid">
            <AnimatePresence mode="popLayout">
              {list.map((w, i) => (
                <motion.div
                  key={w.id}
                  className="dest-col-6"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.35, delay: i * 0.05 }}
                >
                  <article className="dcard" style={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                        <span className="tag aqua">
                          {w.category}
                        </span>
                        <span className={`tag ${w.safetyBadge === 'safe' ? 'safe' : 'caution'}`}>
                          {w.safetyLabel}
                        </span>
                      </div>

                      {/* Clean Neutral Landscape Placeholder Banner (No generic emoji) */}
                      <div
                        style={{
                          height: 100,
                          borderRadius: 'var(--r)',
                          margin: '8px 0 16px',
                          background: 'linear-gradient(135deg, rgba(23,107,69,0.15), rgba(53,185,165,0.22))',
                          border: '1px solid var(--border-color)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '0 20px',
                          position: 'relative',
                          overflow: 'hidden'
                        }}
                      >
                        <div>
                          <span style={{ fontSize: '0.74rem', textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-muted)', fontWeight: 600, display: 'block' }}>
                            Location
                          </span>
                          <strong style={{ fontSize: '1.05rem', color: 'var(--ink)' }}>{w.district} District</strong>
                        </div>
                        <span style={{ fontSize: '0.78rem', color: 'var(--primary)', fontWeight: 600, background: 'var(--white)', padding: '4px 12px', borderRadius: 20, border: '1px solid var(--border-color)' }}>
                          {w.accessibilityLevel}
                        </span>
                      </div>

                      <h3 style={{ fontSize: '1.4rem', marginBottom: 4, color: 'var(--ink)' }}>{w.name}</h3>
                      <div style={{ marginBottom: 10, color: 'var(--ink-muted)', fontSize: '0.88rem' }}>
                        <IconPin style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4, color: '#35B9A5' }} />
                        {w.nearbyTown}
                      </div>

                      <p style={{ fontSize: '0.92rem', color: 'var(--ink-soft)', lineHeight: 1.6, marginBottom: 16 }}>
                        {w.shortDesc}
                      </p>

                      <div className="ibox" style={{ marginBottom: 14 }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                          <div>
                            <span style={{ color: 'var(--ink-muted)', display: 'block', fontSize: '0.76rem' }}>Accessibility</span>
                            <strong style={{ color: 'var(--ink)' }}>{w.accessibilityLevel}</strong>
                          </div>
                          <div>
                            <span style={{ color: 'var(--ink-muted)', display: 'block', fontSize: '0.76rem' }}>Best Season</span>
                            <strong style={{ color: 'var(--ink)' }}>{w.bestSeason.recommended.split(' ')[0]} to {w.bestSeason.recommended.split(' ')[2]}</strong>
                          </div>
                        </div>
                      </div>

                      <div style={{ fontSize: '0.82rem', marginBottom: 16, lineHeight: 1.5, color: 'var(--ink-soft)', background: 'var(--white)', padding: '10px 12px', borderRadius: 'var(--r-sm)', border: '1px solid var(--border-color)' }}>
                        <strong style={{ color: 'var(--primary)' }}>Safety Context:</strong> {w.safetyNote}
                      </div>
                    </div>

                    <div style={{ marginTop: 12 }}>
                      <Link
                        to={`/${w.id}`}
                        className="btn"
                        style={{ width: '100%', justifyContent: 'center', display: 'flex', alignItems: 'center', gap: 6 }}
                      >
                        Explore Details →
                      </Link>
                    </div>
                  </article>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <div className="proof glass" style={{ marginTop: 40 }}>
            <div className="proof-icon">✓</div>
            <p>
              <strong>Responsible Tourism Prototype:</strong> This platform avoids permanent "safe" labels. Natural waterfalls vary dynamically with seasonal rain and river flow. Always check weather advisories before stepping near water.
            </p>
          </div>
        </div>
      </section>
    </PageWrap>
  )
}
