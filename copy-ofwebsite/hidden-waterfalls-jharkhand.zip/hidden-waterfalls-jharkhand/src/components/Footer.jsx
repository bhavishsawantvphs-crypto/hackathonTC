import { Link } from 'react-router-dom'
import { IconLeaf } from './icons'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <div className="brand" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
              <IconLeaf style={{ color: 'var(--primary)' }} />
              <span>
                <b>Hidden &amp; Lesser-Known Waterfalls</b> · Jharkhand Eco-Tourism
              </span>
            </div>
            <p style={{ fontSize: '0.88rem', color: 'var(--ink-soft)', lineHeight: 1.6, maxWidth: 440 }}>
              Helping tourists discover offbeat and lesser-known waterfalls across Jharkhand with verified
              accessibility, emergency medical references, seasonal safety notes, and responsible tourism guidance.
            </p>
          </div>

          <div>
            <h5>Quick Discovery</h5>
            <Link to="/#discovery">6 Curated Waterfalls</Link>
            <Link to="/#map">Interactive Constellation Map</Link>
            <Link to="/responsible-travel">Responsible Travel Guidelines</Link>
          </div>

          <div>
            <h5>Verified Prototype</h5>
            <p style={{ fontSize: '0.84rem', color: 'var(--ink-muted)', lineHeight: 1.6 }}>
              Hackathon Eco-Tourism Prototype.<br />
              Data verified against Jharkhand tourism publications and district health directories.
            </p>
          </div>
        </div>

        <div className="footer-base">
          <span>© 2026 Hidden &amp; Lesser-Known Waterfalls of Jharkhand · 2-Day Hackathon Prototype</span>
          <span>Verified Non-Invented Data Standard</span>
        </div>
      </div>
    </footer>
  )
}
