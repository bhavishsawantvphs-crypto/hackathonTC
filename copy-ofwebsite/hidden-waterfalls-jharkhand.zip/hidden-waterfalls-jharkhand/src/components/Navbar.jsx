import { useEffect, useState } from 'react'
import { NavLink, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { IconArrow } from './icons'

const LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/#map', label: 'Interactive Map' },
  { to: '/#discovery', label: 'Hidden & Lesser-Known Waterfalls' },
  { to: '/responsible-travel', label: 'Responsible Travel' }
]

function Logo() {
  return (
    <svg className="logo" viewBox="0 0 34 34" width="34" height="34" fill="none">
      <circle cx="17" cy="17" r="16" fill="rgba(79,175,91,0.14)" stroke="#176B45" strokeWidth="1.5" />
      <path d="M17 7c-3.5 5.5-8 10-8 14.5a8 8 0 0 0 16 0c0-4.5-4.5-9-8-14.5z" fill="#176B45" />
      <path d="M14 19c0 2 1.5 3.5 3 3.5s3-1.5 3-3.5" stroke="#8EDB68" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  )
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className={`nav ${scrolled ? 'scrolled' : ''}`}>
      <div className="wrap">
        <div className="nav-inner">
          <Link to="/" className="brand" onClick={() => setOpen(false)}>
            <Logo />
            <span>
              <b>Hidden &amp; Lesser-Known Waterfalls</b>
              <span style={{ fontWeight: 500, color: 'var(--ink-muted)', fontSize: '0.88rem', marginLeft: 6 }}>· Jharkhand</span>
            </span>
          </Link>

          <nav className="nav-links">
            {LINKS.map((l) => (
              l.to.startsWith('/#') ? (
                <a key={l.to} href={l.to}>
                  {l.label}
                </a>
              ) : (
                <NavLink key={l.to} to={l.to} end={l.end}>
                  {l.label}
                </NavLink>
              )
            ))}
          </nav>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <a href="#discovery" className="btn small">
              Explore Waterfalls <IconArrow />
            </a>
            <button className="nav-burger" aria-label="Menu" onClick={() => setOpen((v) => !v)}>
              <span style={{ fontSize: '1.2rem' }}>☰</span>
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            className="mobile-menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {LINKS.map((l) => (
              l.to.startsWith('/#') ? (
                <a key={l.to} href={l.to} onClick={() => setOpen(false)}>
                  {l.label}
                </a>
              ) : (
                <NavLink key={l.to} to={l.to} end={l.end} onClick={() => setOpen(false)}>
                  {l.label}
                </NavLink>
              )
            ))}
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  )
}
