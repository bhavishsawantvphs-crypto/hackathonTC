import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { WATERFALLS } from '../data/waterfalls'
import { IconArrow, IconPin } from './icons'

export default function InteractiveMap({ filter = 'all', onSelectWaterfall, selectedId }) {
  const [activePin, setActivePin] = useState(WATERFALLS.find(w => w.id === selectedId) || WATERFALLS[0])

  const handlePinClick = (wf) => {
    setActivePin(wf)
    if (onSelectWaterfall) onSelectWaterfall(wf)
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1.45fr) minmax(0,1fr)', gap: 24, alignItems: 'stretch' }} className="explore-layout">
      {/* MAP SVG CANVAS */}
      <div className="map-area glass" style={{ position: 'relative', overflow: 'hidden', minHeight: 400, borderRadius: 'var(--r-lg)', padding: 16 }}>
        <div className="map-canvas" style={{ position: 'relative', width: '100%', height: '100%', minHeight: 380 }}>
          <svg className="contour" viewBox="0 0 100 80" preserveAspectRatio="none" aria-hidden="true" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.85 }}>
            {[12, 26, 40, 54, 68].map((y, i) => (
              <path
                key={i}
                d={`M0 ${y + Math.sin(i) * 3} Q 25 ${y - 6} 50 ${y} T 100 ${y - 2}`}
                fill="none"
                stroke="#35B9A5"
                strokeWidth="0.4"
                strokeOpacity="0.4"
              />
            ))}
            {[18, 36, 54, 72, 88].map((x, i) => (
              <path
                key={'v' + i}
                d={`M${x} 0 Q ${x + 4} 40 ${x} 80`}
                fill="none"
                stroke="#4FAF5B"
                strokeWidth="0.3"
                strokeOpacity="0.3"
              />
            ))}
          </svg>

          {WATERFALLS.map((wf, i) => {
            const isSelected = activePin?.id === wf.id
            const isMatch = filter === 'all' || 
              (filter === 'suitable' && wf.safetyStatus === 'suitable') ||
              (filter === 'caution' && wf.safetyStatus === 'caution') ||
              (filter === wf.accessibilityCategory) ||
              (filter === wf.categoryKey)

            return (
              <motion.button
                key={wf.id}
                className={`pin ${!isMatch ? 'dim' : ''} ${isSelected ? 'active' : ''}`}
                style={{
                  left: `${wf.x}%`,
                  top: `${wf.y}%`,
                  cursor: 'pointer',
                  zIndex: isSelected ? 10 : 2
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: isSelected ? 1.2 : 1, opacity: isMatch ? 1 : 0.35 }}
                transition={{ delay: 0.1 + i * 0.06, type: 'spring', stiffness: 280, damping: 20 }}
                onClick={() => handlePinClick(wf)}
                aria-label={wf.name}
              >
                <span className="dot" style={{ background: '#35B9A5', boxShadow: isSelected ? `0 0 0 5px rgba(53,185,165,0.35), 0 0 14px #35B9A5` : 'none' }} />
                <span className="plabel" style={{ fontWeight: isSelected ? 700 : 500, color: 'var(--ink)' }}>{wf.name.replace(' Falls', '').replace(' Waterfall', '').replace(' Waterfalls', '')}</span>
              </motion.button>
            )
          })}
        </div>
        <div style={{ position: 'absolute', bottom: 12, left: 16, right: 16, fontSize: '0.78rem', color: 'var(--ink-muted)' }}>
          📍 <span style={{ color: '#35B9A5', fontWeight: 600 }}>Interactive Waterfall Map</span> · Click markers to preview accessibility and safety context.
        </div>
      </div>

      {/* SELECTED WATERFALL LIVE PREVIEW PANEL */}
      <div className="glass" style={{ padding: '26px', borderRadius: 'var(--r-lg)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <AnimatePresence mode="wait">
          {activePin && (
            <motion.div
              key={activePin.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.28 }}
              style={{ display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'space-between' }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
                  <span className="tag aqua">
                    {activePin.category}
                  </span>
                  <span className={`tag ${activePin.safetyBadge === 'safe' ? 'safe' : 'caution'}`}>
                    {activePin.safetyLabel}
                  </span>
                </div>

                <h3 style={{ fontSize: '1.5rem', marginBottom: 4, color: 'var(--ink)' }}>{activePin.name}</h3>
                <p style={{ fontSize: '0.88rem', color: 'var(--ink-muted)', marginBottom: 14 }}>
                  <IconPin style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4, color: '#35B9A5' }} />
                  {activePin.nearbyTown}
                </p>

                <p style={{ fontSize: '0.94rem', color: 'var(--ink-soft)', lineHeight: 1.6, marginBottom: 16 }}>
                  {activePin.shortDesc}
                </p>

                <div className="ibox" style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: '0.8rem', color: 'var(--ink-muted)', marginBottom: 2 }}>Accessibility Rating</div>
                  <div style={{ fontSize: '0.94rem', fontWeight: 600, color: 'var(--ink)' }}>{activePin.accessibilityLevel}</div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--ink-soft)', marginTop: 4 }}>{activePin.accessibilityDetails.trekRequirement}</div>
                </div>

                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', fontSize: '0.82rem' }}>
                  <span className="tag" style={{ background: 'var(--white)', borderColor: 'var(--border-color)' }}>
                    📅 {activePin.bestSeason.recommended.split('(')[0]}
                  </span>
                  <span className="tag safe">
                    🌿 Prototype Eco-Score: {activePin.ecoScore.score}/100
                  </span>
                </div>
              </div>

              <div style={{ marginTop: 24 }}>
                <Link
                  to={`/${activePin.id}`}
                  className="btn"
                  style={{ width: '100%', justifyContent: 'center', display: 'flex', alignItems: 'center', gap: 8 }}
                >
                  Explore Details & Safety Brief <IconArrow />
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
