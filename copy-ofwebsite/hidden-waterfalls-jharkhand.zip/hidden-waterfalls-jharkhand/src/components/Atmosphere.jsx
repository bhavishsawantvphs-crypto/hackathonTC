export default function Atmosphere() {
  return (
    <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: '-10%', right: '-5%', width: '55vw', height: '55vw', background: 'radial-gradient(circle, rgba(53,185,165,0.09) 0%, transparent 70%)', filter: 'blur(40px)' }} />
      <div style={{ position: 'absolute', top: '40%', left: '-10%', width: '50vw', height: '50vw', background: 'radial-gradient(circle, rgba(79,175,91,0.08) 0%, transparent 65%)', filter: 'blur(50px)' }} />
    </div>
  )
}
